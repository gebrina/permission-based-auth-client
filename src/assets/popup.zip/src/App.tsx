import './App.css';
import { Card } from './Card';

function App() {
  return (
    <div className="container">
      {Array.from({ length: 5 }).map((_, index) => (
        <Card key={index} buttonId={'button' + (index + 1)} />
      ))}
    </div>
  );
}

export default App;
