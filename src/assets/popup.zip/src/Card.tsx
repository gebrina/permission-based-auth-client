import { BiDotsVertical } from 'react-icons/bi';
import { Popup } from './Popup';

export const Card: React.FC<{ buttonId: string }> = ({ buttonId }) => {
  const items = ['Buy Now', 'Learn More', 'Mark as Favorite'];
  return (
    <div className="card">
      <div>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia
        numquam ut consequatur tenetur! Eos accusamus quisquam officia, nesciunt
        ratione nemo? Doloremque.
      </div>
      <button id={buttonId}>
        <BiDotsVertical />
      </button>
      <Popup triggerId={buttonId} items={items} />
    </div>
  );
};
