import { useEffect, useRef, useState } from 'react';
import { BiHeart } from 'react-icons/bi';

type PopuProps = {
  triggerId: string;
  items: string[];
};

export const Popup: React.FC<PopuProps> = ({ items, triggerId }) => {
  const [triggerdId, setTriggerdId] = useState<string | null>('');

  useEffect(() => {
    const handleTriggerClick = (e: Event) => {
      const traget = e.target as HTMLElement;
      const button = traget.parentNode as HTMLButtonElement;
      const id = button.getAttribute('id');
      setTriggerdId(id);
    };

    document.addEventListener('click', handleTriggerClick);

    return () => document.removeEventListener('click', handleTriggerClick);
  }, []);

  return triggerId === triggerdId ? (
    <ul className="popup">
      {items.map((item) => (
        <li key={item}>
          <BiHeart /> {item}
        </li>
      ))}
    </ul>
  ) : null;
};
